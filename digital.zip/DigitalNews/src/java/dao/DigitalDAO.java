/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import context.DBContext;
import entity.News;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 *
 * @author XQ
 */
public class DigitalDAO {

    public News getLastNews() throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "select TOP 1title,image,fullcontent,writter,timePost from news\n"
                + "order by timePost desc";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            if (rs.next()) {
                News n = new News();
                n.setTitle(rs.getString("title"));
                n.setImage("images/" + rs.getString("image"));
                n.setFullContent(rs.getString("fullcontent"));
                n.setWritter(rs.getString("writter"));
                SimpleDateFormat sd = new SimpleDateFormat("MMM dd yyyy - h:mm");
                SimpleDateFormat sd2 = new SimpleDateFormat("a");
                n.setTimePost(sd.format(rs.getTimestamp("timePost")) 
                        + sd2.format(rs.getTimestamp("timePost")).toLowerCase());
                return n;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(conn, ps, rs);
        }
        return null;
    }

    public String getSub() throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "select TOP 1subContent from news\n"
                + "order by timePost desc";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("subContent");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } finally {
            db.closeConnection(conn, ps, rs);
        }
        return null;
    }

    public ArrayList<News> getTop5() throws Exception {
        ArrayList<News> top5 = new ArrayList<>();
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "select TOP 5id, title from news\n"
                + "where id not in (select top 1id from news order by timePost desc)\n"
                + "order by timePost desc";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                News n = new News();
                n.setId(rs.getInt("id"));
                n.setTitle(rs.getString("tite"));
                top5.add(n);
            }
            return top5;
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(conn, ps, rs);
        }
    }

    public News getByID(String id) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "select title, image, fullcontent, writter, timePost from news \n"
                + "where id = ?";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                News n = new News();
                n.setTitle(rs.getString("title"));
                n.setImage("images/" + rs.getString("image"));
                n.setFullContent(rs.getString("fullcontent"));
                n.setWritter(rs.getString("writter"));
                SimpleDateFormat sd = new SimpleDateFormat("MMM dd yyyy - h:mm");
                SimpleDateFormat sd2 = new SimpleDateFormat("a");
                n.setTimePost(sd.format(rs.getTimestamp("timePost")) 
                        + sd2.format(rs.getTimestamp("timePost")).toLowerCase());
                return n;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(conn, ps, rs);
        }
        return null;
    }

    public ArrayList<News> getNewsbySearch(String title, int numpage) throws Exception {
        ArrayList<News> search = new ArrayList<>();
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT id,title,[image], subContent FROM\n"
                + "(SELECT ROW_NUMBER() OVER (ORDER BY id ASC) as stt,id,title,[image], subContent\n"
                + "FROM news where title like '%' + ? + '%') tbl\n"
                + "WHERE stt >= ?\n"
                + "AND stt <= ?";
        try {
            int pagesize = 3;
            int firstNewsinPage = (numpage - 1) * pagesize + 1;
            int lastNewsinPage = pagesize * numpage;
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, title);
            ps.setInt(2, firstNewsinPage);
            ps.setInt(3, lastNewsinPage);
            rs = ps.executeQuery();
            while (rs.next()) {
                News n = new News();
                n.setId(rs.getInt("id"));
                n.setTitle(rs.getString("title"));
                n.setImage("images/" + rs.getString("image"));
                n.setSubContent(rs.getString("subContent"));
                search.add(n);
            }
            return search;
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(conn, ps, rs);
        }
    }

    public int getCountSearch(String title) throws Exception {
        DBContext db = new DBContext();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT COUNT(id) as 'allpage' FROM news\n"
                + "WHERE title like '%' + ? + '%'";
        try {
            conn = db.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, title);
            rs = ps.executeQuery();
            if (rs.next()) {
                int pagesize = 3;
                int totalPage = rs.getInt("allpage") / pagesize;
                if (rs.getInt("allpage") % pagesize != 0) {
                    totalPage++;
                }
                return totalPage;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            db.closeConnection(conn, ps, rs);
        }
        return 0;
    }
}
