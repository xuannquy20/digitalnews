/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import entity.News;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author XQ
 */
public class SearchController extends BaseRight {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void processGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String key = request.getParameter("key");
            String numpage = request.getParameter("page");
            boolean checkPage = false;
            
            //get total pages found with keyword
            int totalPage = dao.getCountSearch(key);
            
            try {
                if (totalPage == 0 || key.equals("")) {
                    //If can't find any news, notify the user
                    request.setAttribute("notfound", "No results were found");
                } else if (Integer.parseInt(numpage) >= 1 && Integer.parseInt(numpage) <= totalPage) {
                    //If the page number is in the valid range, set checkPage to true
                    checkPage = true;
                } else {
                    //If the page number is not within the valid range, notify the user
                    request.setAttribute("notfound", "Number page \"" + numpage + "\" is not valid");
                }
            } catch (Exception e) {
                //If the page number string received is not a number, report an error
                request.setAttribute("notfound", "Number page must is an integer");
            }

            //Get the data for "right"
            request.setAttribute("key", key);

            if (checkPage) {
                //If the page number is not within the valid range, get news
                ArrayList<News> searchnews = dao.getNewsbySearch(key, Integer.parseInt(numpage));
                request.setAttribute("searchnews", searchnews);
                request.setAttribute("checkPage", checkPage);
                request.setAttribute("numpage", numpage);
                request.setAttribute("allpage", totalPage);
            }

            request.setAttribute("checkPage", checkPage);
            request.getRequestDispatcher("Search.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("error", "System error, please come back later"
                    + "<br>"
                    + "<a href=\"home\">>>Back to home</a>");
            request.getRequestDispatcher("Error.jsp").forward(request, response);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void processPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String key = request.getParameter("key");
            //switch to doGet with page number
            response.sendRedirect("search?key=" + key + "&page=1");
        } catch (Exception e) {
            request.setAttribute("error", "System error, please come back later"
                    + "<br>"
                    + "<a href=\"home\">>>Back to home</a>");
            request.getRequestDispatcher("Error.jsp").forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
}
